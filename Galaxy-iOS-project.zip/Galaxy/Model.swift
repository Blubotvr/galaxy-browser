import SwiftUI
import WebKit
import AVFoundation

let searchBase = "https://duckduckgo.com/?q="
let themeParams = "&kae=d&k7=0b0d21&k8=e8eaff&k9=4de1ff&kaa=b78cff&kj=0f1230"
let safariUA = "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1"
let aiProviders: [(String, String)] = [
    ("Claude", "https://claude.ai/new"), ("Gemini", "https://gemini.google.com/app"),
    ("Copilot", "https://copilot.microsoft.com"), ("ChatGPT", "https://chatgpt.com")
]
let trackerDomains = ["google-analytics.com", "googletagmanager.com", "doubleclick.net", "googlesyndication.com",
    "googleadservices.com", "connect.facebook.net", "scorecardresearch.com", "hotjar.com", "segment.io",
    "mixpanel.com", "amazon-adsystem.com", "taboola.com", "outbrain.com", "criteo.com", "quantserve.com",
    "adnxs.com", "pubmatic.com", "rubiconproject.com", "clarity.ms", "fullstory.com", "mouseflow.com",
    "crazyegg.com", "bat.bing.com", "ads-twitter.com", "analytics.tiktok.com"]
let blockedExtensions: Set<String> = ["exe", "msi", "bat", "cmd", "scr", "com", "apk", "jar", "vbs", "ps1", "dll", "dmg", "pkg"]

func homeURL() -> URL? { Bundle.main.url(forResource: "home", withExtension: "html") }

// MARK: - Shared private browser engine (in-memory storage + tracker blocking + space theme)
final class Engine {
    static let shared = Engine()
    let config = WKWebViewConfiguration()

    init() {
        config.websiteDataStore = WKWebsiteDataStore.nonPersistent()   // nothing saved to disk
        config.allowsInlineMediaPlayback = true

        // Space theme for DuckDuckGo pages
        var css = ""
        if let u = Bundle.main.url(forResource: "space", withExtension: "css"), let s = try? String(contentsOf: u) { css = s }
        var literal = "\"\""
        if let d = try? JSONSerialization.data(withJSONObject: [css], options: []),
           let s = String(data: d, encoding: .utf8) {
            literal = String(s.dropFirst().dropLast())
        }
        let js = "(function(){if(!/(^|\\.)duckduckgo\\.com$/.test(location.hostname))return;" +
                 "var s=document.createElement('style');s.textContent=" + literal + ";" +
                 "document.documentElement.appendChild(s);})();"
        config.userContentController.addUserScript(
            WKUserScript(source: js, injectionTime: .atDocumentEnd, forMainFrameOnly: true))

        // Tracker blocking
        var rules: [[String: Any]] = []
        for d in trackerDomains {
            let esc = d.replacingOccurrences(of: ".", with: "\\.")
            rules.append(["trigger": ["url-filter": esc], "action": ["type": "block"]])
        }
        if let data = try? JSONSerialization.data(withJSONObject: rules, options: []),
           let json = String(data: data, encoding: .utf8) {
            WKContentRuleListStore.default().compileContentRuleList(
                forIdentifier: "galaxy-trackers", encodedContentRuleList: json) { list, _ in
                if let list = list {
                    DispatchQueue.main.async { self.config.userContentController.add(list) }
                }
            }
        }
    }
}

struct AlertInfo: Identifiable {
    let id = UUID()
    let title: String
    let message: String
    var yes: String? = nil
    var handler: ((Bool) -> Void)? = nil
}

struct ShareItem: Identifiable {
    let id = UUID()
    let url: URL
}

// MARK: - A single browser tab
final class Tab: NSObject, Identifiable, WKNavigationDelegate, WKUIDelegate, WKDownloadDelegate {
    let id = UUID()
    let webView: WKWebView
    weak var model: BrowserModel?
    var observers: [NSKeyValueObservation] = []
    var downloadDest: URL?

    var title: String {
        if let t = webView.title, !t.isEmpty { return t }
        return "New Tab"
    }

    init(model: BrowserModel, url: URL?) {
        self.webView = WKWebView(frame: .zero, configuration: Engine.shared.config)
        self.model = model
        super.init()
        webView.navigationDelegate = self
        webView.uiDelegate = self
        webView.customUserAgent = safariUA
        webView.allowsBackForwardNavigationGestures = true
        webView.isOpaque = false
        webView.backgroundColor = UIColor(red: 0.04, green: 0.05, blue: 0.13, alpha: 1)
        webView.scrollView.backgroundColor = UIColor(red: 0.04, green: 0.05, blue: 0.13, alpha: 1)
        observers.append(webView.observe(\.url) { [weak self] _, _ in self?.changed() })
        observers.append(webView.observe(\.title) { [weak self] _, _ in self?.changed() })
        if let url = url { webView.load(URLRequest(url: url)) } else { loadHome() }
    }

    func loadHome() {
        if let u = homeURL() { webView.loadFileURL(u, allowingReadAccessTo: u.deletingLastPathComponent()) }
    }

    func changed() {
        DispatchQueue.main.async { self.model?.tabChanged(self) }
    }

    // Search detected -> start the search music
    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction,
                 decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        if let url = navigationAction.request.url,
           navigationAction.targetFrame?.isMainFrame ?? true,
           url.absoluteString.hasPrefix(searchBase) {
            model?.searchStarted()
        }
        decisionHandler(.allow)
    }

    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        model?.pageLoaded(self)
    }

    // Downloads: ask first, block program files
    func webView(_ webView: WKWebView, decidePolicyFor navigationResponse: WKNavigationResponse,
                 decisionHandler: @escaping (WKNavigationResponsePolicy) -> Void) {
        if navigationResponse.canShowMIMEType { decisionHandler(.allow); return }
        let name = navigationResponse.response.suggestedFilename ?? "file"
        let ext = (name as NSString).pathExtension.lowercased()
        if blockedExtensions.contains(ext) {
            model?.show("Download blocked", "\"\(name)\" is a program file type that can be dangerous, so Galaxy blocked it.")
            decisionHandler(.cancel)
            return
        }
        guard let model = model else { decisionHandler(.cancel); return }
        model.confirm(title: "Download this file?",
                      message: "\"\(name)\"\n\niPhone apps can't virus-scan files, so only download from sites you trust.",
                      yes: "Download") { ok in
            decisionHandler(ok ? .download : .cancel)
        }
    }

    func webView(_ webView: WKWebView, navigationResponse: WKNavigationResponse, didBecome download: WKDownload) {
        download.delegate = self
    }
    func webView(_ webView: WKWebView, navigationAction: WKNavigationAction, didBecome download: WKDownload) {
        download.delegate = self
    }

    func download(_ download: WKDownload, decideDestinationUsing response: URLResponse,
                  suggestedFilename: String, completionHandler: @escaping (URL?) -> Void) {
        let dir = FileManager.default.temporaryDirectory.appendingPathComponent("galaxy-downloads", isDirectory: true)
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        let safe = suggestedFilename.replacingOccurrences(of: "/", with: "_")
        let url = dir.appendingPathComponent(UUID().uuidString + "-" + safe)
        downloadDest = url
        completionHandler(url)
    }
    func downloadDidFinish(_ download: WKDownload) {
        if let d = downloadDest { model?.share = ShareItem(url: d) }
    }
    func download(_ download: WKDownload, didFailWithError error: Error, resumeData: Data?) {
        model?.show("Download failed", error.localizedDescription)
    }

    // Links that open a new window become new tabs
    func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration,
                 for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
        if let u = navigationAction.request.url {
            DispatchQueue.main.async { self.model?.newTab(u) }
        }
        return nil
    }
}

// MARK: - App state: tabs, music, alerts
final class BrowserModel: NSObject, ObservableObject, AVAudioPlayerDelegate {
    @Published var tabs: [Tab] = []
    @Published var current: Tab?
    @Published var address = ""
    @Published var status = "Welcome to Galaxy \u{1F30C}"
    @Published var showAI = false
    @Published var showMusic = false
    @Published var alert: AlertInfo?
    @Published var share: ShareItem?
    @Published var tracks: [String] = []
    @Published var trackIndex = 0
    @Published var isPlaying = false
    @Published var volume: Float = 0.6 { didSet { player?.volume = volume } }
    @Published var aiChoice = 0 { didSet { loadAI() } }
    @Published var playOnSearch: Bool { didSet { UserDefaults.standard.set(playOnSearch, forKey: "playOnSearch") } }
    @Published var stopOnLoad: Bool { didSet { UserDefaults.standard.set(stopOnLoad, forKey: "stopOnLoad") } }

    let aiWebView: WKWebView
    var player: AVAudioPlayer?

    override init() {
        let d = UserDefaults.standard
        playOnSearch = (d.object(forKey: "playOnSearch") as? Bool) ?? true
        stopOnLoad = d.bool(forKey: "stopOnLoad")
        aiWebView = WKWebView(frame: .zero, configuration: Engine.shared.config)
        super.init()
        aiWebView.customUserAgent = safariUA
        loadTracks()
        newTab(nil)
    }

    // ----- tabs
    func newTab(_ url: URL?) {
        let t = Tab(model: self, url: url)
        tabs.append(t)
        select(t)
    }
    func select(_ t: Tab) {
        current = t
        syncAddress()
    }
    func closeTab(_ t: Tab) {
        guard let i = tabs.firstIndex(where: { $0 === t }) else { return }
        tabs.remove(at: i)
        if tabs.isEmpty { newTab(nil) }
        else if current === t { select(tabs[max(0, i - 1)]) }
    }
    func tabChanged(_ t: Tab) {
        objectWillChange.send()
        if t === current { syncAddress() }
    }
    func syncAddress() {
        if let u = current?.webView.url, !u.isFileURL { address = u.absoluteString } else { address = "" }
    }
    func goHome() { current?.loadHome() }

    func go() {
        let t = address.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !t.isEmpty, let tab = current else { return }
        let lower = t.lowercased()
        let hasScheme = lower.hasPrefix("http://") || lower.hasPrefix("https://")
        let isSearch = !hasScheme && (t.contains(" ") || !t.contains("."))
        var url: URL?
        if isSearch {
            let allowed = CharacterSet(charactersIn: "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-._~")
            let q = t.addingPercentEncoding(withAllowedCharacters: allowed) ?? t
            url = URL(string: searchBase + q + themeParams)
        } else {
            url = URL(string: hasScheme ? t : "https://" + t)
        }
        if let url = url { tab.webView.load(URLRequest(url: url)) }
    }

    // ----- alerts
    func show(_ title: String, _ message: String) {
        if alert == nil { alert = AlertInfo(title: title, message: message) }
    }
    func confirm(title: String, message: String, yes: String, _ handler: @escaping (Bool) -> Void) {
        if alert != nil { handler(false); return }
        alert = AlertInfo(title: title, message: message, yes: yes, handler: handler)
    }

    // ----- VPN (iOS apps can't switch a VPN on; Galaxy asks, then opens Proton's page)
    func vpnTapped() {
        confirm(title: "Galaxy needs your permission",
                message: "Galaxy can open the Proton VPN Free page (free, no data limit, audited no-logs policy). iPhone apps can't turn a VPN on for you, so install Proton VPN there and switch it on in its own app.\n\nOpen it now?",
                yes: "Open") { ok in
            if ok, let u = URL(string: "https://protonvpn.com/download") { UIApplication.shared.open(u) }
        }
    }

    // ----- AI
    func loadAI() {
        if let u = URL(string: aiProviders[aiChoice].1) { aiWebView.load(URLRequest(url: u)) }
    }

    // ----- search events
    func searchStarted() { if playOnSearch { startMusic() } }
    func pageLoaded(_ t: Tab) { if stopOnLoad && t === current { stopMusic() } }

    // ----- music
    var musicDir: URL {
        let u = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("Music", isDirectory: true)
        try? FileManager.default.createDirectory(at: u, withIntermediateDirectories: true)
        return u
    }
    func loadTracks() {
        let names = UserDefaults.standard.stringArray(forKey: "tracks") ?? []
        tracks = names.filter { FileManager.default.fileExists(atPath: musicDir.appendingPathComponent($0).path) }
    }
    func saveTracks() { UserDefaults.standard.set(tracks, forKey: "tracks") }
    func importFiles(_ urls: [URL]) {
        for u in urls {
            let access = u.startAccessingSecurityScopedResource()
            defer { if access { u.stopAccessingSecurityScopedResource() } }
            let name = u.lastPathComponent
            if tracks.contains(name) { continue }
            let dest = musicDir.appendingPathComponent(name)
            try? FileManager.default.removeItem(at: dest)
            if (try? FileManager.default.copyItem(at: u, to: dest)) != nil { tracks.append(name) }
        }
        saveTracks()
    }
    func removeTracks(at offsets: IndexSet) {
        for i in offsets { try? FileManager.default.removeItem(at: musicDir.appendingPathComponent(tracks[i])) }
        tracks.remove(atOffsets: offsets)
        trackIndex = 0
        saveTracks()
    }
    func startMusic(index: Int? = nil, force: Bool = false) {
        guard !tracks.isEmpty else { status = "Add some music first (\u{1F3B5} Music)."; return }
        if !force, player?.isPlaying == true { return }
        if let i = index { trackIndex = i }
        if trackIndex >= tracks.count { trackIndex = 0 }
        let url = musicDir.appendingPathComponent(tracks[trackIndex])
        try? AVAudioSession.sharedInstance().setCategory(.playback)
        try? AVAudioSession.sharedInstance().setActive(true)
        player = try? AVAudioPlayer(contentsOf: url)
        player?.delegate = self
        player?.volume = volume
        player?.play()
        isPlaying = player?.isPlaying ?? false
    }
    func stopMusic() {
        player?.stop()
        isPlaying = false
    }
    func audioPlayerDidFinishPlaying(_ player: AVAudioPlayer, successfully flag: Bool) {
        if !tracks.isEmpty { startMusic(index: (trackIndex + 1) % tracks.count, force: true) }
    }
}
