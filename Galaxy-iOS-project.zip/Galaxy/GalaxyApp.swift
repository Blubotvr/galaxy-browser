import SwiftUI
import WebKit
import UniformTypeIdentifiers

enum Theme {
    static let bg = Color(red: 0.043, green: 0.051, blue: 0.129)
    static let panel = Color(red: 0.078, green: 0.094, blue: 0.212)
    static let accent = Color(red: 0.541, green: 0.361, blue: 1.0)
    static let cyan = Color(red: 0.302, green: 0.882, blue: 1.0)
}

@main
struct GalaxyApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView().preferredColorScheme(.dark)
        }
    }
}

struct WebHost: UIViewRepresentable {
    let webView: WKWebView
    func makeUIView(context: Context) -> WKWebView { webView }
    func updateUIView(_ uiView: WKWebView, context: Context) {}
}

struct ShareSheet: UIViewControllerRepresentable {
    let url: URL
    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: [url], applicationActivities: nil)
    }
    func updateUIViewController(_ uiViewController: UIActivityViewController, context: Context) {}
}

func makeAlert(_ a: AlertInfo) -> Alert {
    if let yes = a.yes {
        return Alert(title: Text(a.title), message: Text(a.message),
                     primaryButton: .default(Text(yes), action: { a.handler?(true) }),
                     secondaryButton: .cancel(Text("No"), action: { a.handler?(false) }))
    }
    return Alert(title: Text(a.title), message: Text(a.message), dismissButton: .default(Text("OK")))
}

struct ContentView: View {
    @StateObject private var m = BrowserModel()

    var body: some View {
        VStack(spacing: 0) {
            topBar
            tabStrip
            if let t = m.current {
                WebHost(webView: t.webView).id(t.id)
            } else {
                Color.clear
            }
            Text(m.status)
                .font(.caption2).foregroundColor(Theme.cyan.opacity(0.8))
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(.horizontal, 10).padding(.vertical, 3)
            bottomBar
        }
        .background(Theme.bg.ignoresSafeArea())
        .alert(item: $m.alert) { makeAlert($0) }
    }

    var topBar: some View {
        HStack(spacing: 8) {
            TextField("Search the universe or enter a web address...", text: $m.address)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled(true)
                .keyboardType(.webSearch)
                .submitLabel(.go)
                .onSubmit { m.go() }
                .padding(.horizontal, 14).padding(.vertical, 9)
                .background(Theme.panel)
                .overlay(RoundedRectangle(cornerRadius: 18).stroke(Theme.accent.opacity(0.6), lineWidth: 1))
                .clipShape(RoundedRectangle(cornerRadius: 18))
            Button { m.newTab(nil) } label: { Image(systemName: "plus.square.on.square") }
        }
        .padding(8)
        .tint(Theme.cyan)
        .sheet(item: $m.share) { ShareSheet(url: $0.url) }
    }

    var tabStrip: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 4) {
                ForEach(m.tabs) { tab in
                    HStack(spacing: 6) {
                        Text(tab.title).lineLimit(1).font(.footnote).frame(maxWidth: 130)
                        Button { m.closeTab(tab) } label: { Image(systemName: "xmark").font(.caption2) }
                    }
                    .padding(.horizontal, 10).padding(.vertical, 6)
                    .background(tab === m.current ? Theme.accent.opacity(0.6) : Theme.panel)
                    .clipShape(RoundedRectangle(cornerRadius: 10))
                    .onTapGesture { m.select(tab) }
                }
            }
            .padding(.horizontal, 8)
        }
        .padding(.bottom, 4)
        .tint(Theme.cyan)
    }

    var bottomBar: some View {
        HStack {
            Button { m.current?.webView.goBack() } label: { Image(systemName: "chevron.left") }
            Spacer()
            Button { m.current?.webView.goForward() } label: { Image(systemName: "chevron.right") }
            Spacer()
            Button { m.goHome() } label: { Image(systemName: "house") }
            Spacer()
            Button { m.vpnTapped() } label: { Image(systemName: "network.badge.shield.half.filled") }
            Spacer()
            Button { m.showAI = true } label: { Image(systemName: "sparkles") }
            Spacer()
            Button { m.showMusic = true } label: { Image(systemName: "music.note") }
        }
        .font(.title3)
        .tint(Theme.cyan)
        .padding(.horizontal, 22).padding(.vertical, 10)
        .background(Theme.panel.ignoresSafeArea(edges: .bottom))
        .sheet(isPresented: $m.showAI) { AIView(m: m) }
        .sheet(isPresented: $m.showMusic) { MusicView(m: m) }
    }
}

struct AIView: View {
    @ObservedObject var m: BrowserModel
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        VStack(spacing: 8) {
            HStack {
                Text("\u{2728} Galaxy AI").font(.headline).foregroundColor(Theme.cyan)
                Spacer()
                Button("Done") { dismiss() }
            }
            Picker("AI", selection: $m.aiChoice) {
                ForEach(0..<aiProviders.count, id: \.self) { Text(aiProviders[$0].0).tag($0) }
            }
            .pickerStyle(.segmented)
            WebHost(webView: m.aiWebView).clipShape(RoundedRectangle(cornerRadius: 10))
        }
        .padding(12)
        .background(Theme.bg.ignoresSafeArea())
        .tint(Theme.cyan)
        .onAppear { if m.aiWebView.url == nil { m.loadAI() } }
    }
}

struct MusicView: View {
    @ObservedObject var m: BrowserModel
    @State private var importing = false
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        VStack(spacing: 10) {
            HStack {
                Text("\u{1F3B5} Search Music").font(.headline).foregroundColor(Theme.cyan)
                Spacer()
                Button("Done") { dismiss() }
            }
            List {
                ForEach(Array(m.tracks.enumerated()), id: \.offset) { i, name in
                    Text(name).lineLimit(1)
                        .foregroundColor(i == m.trackIndex ? Theme.cyan : .white)
                        .listRowBackground(Theme.panel)
                        .contentShape(Rectangle())
                        .onTapGesture { m.trackIndex = i }
                }
                .onDelete { m.removeTracks(at: $0) }
            }
            .listStyle(.plain)
            Text("Tap a song to select it. Swipe left to remove.")
                .font(.caption).foregroundColor(.gray)
            HStack {
                Button("\u{FF0B} Add music") { importing = true }
                Spacer()
                Button("\u{25B6} Play") { m.startMusic(index: m.trackIndex, force: true) }
                Button("\u{25A0} Stop") { m.stopMusic() }
            }
            HStack {
                Text("Volume")
                Slider(value: Binding(get: { Double(m.volume) }, set: { m.volume = Float($0) }), in: 0...1)
            }
            Toggle("Play music when I search", isOn: $m.playOnSearch)
            Toggle("Stop when results finish loading", isOn: $m.stopOnLoad)
        }
        .padding(12)
        .background(Theme.bg.ignoresSafeArea())
        .tint(Theme.cyan)
        .fileImporter(isPresented: $importing, allowedContentTypes: [.audio], allowsMultipleSelection: true) { result in
            if case .success(let urls) = result { m.importFiles(urls) }
        }
    }
}
